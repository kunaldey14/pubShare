package com.bottomline.payment.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "payment_plan")
public class PayPlan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long paymentId;
	
	@Column(name = "total_amount")
	private BigDecimal totalAmount;
	
	@Column(name = "pay_count")
	private long numberOfPayments;
	
	@Column(name = "pay_amount")
	private BigDecimal regularPaymentAmount;
	
	@Column(name = "last_amount")
	@JsonInclude(JsonInclude.Include.NON_NULL) //Using annotation to exclude non null values as last amount to be only rendered when the value differs from regular amount- line number 34 to 38 in PaymentService.java
	private BigDecimal lastAmount;
	
	public PayPlan(){
		
	}

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public long getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(long numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public BigDecimal getRegularPaymentAmount() {
		return regularPaymentAmount;
	}

	public void setRegularPaymentAmount(BigDecimal regularPaymentAmount) {
		this.regularPaymentAmount = regularPaymentAmount;
	}

	public BigDecimal getLastAmount() {
		return lastAmount;
	}

	public void setLastAmount(BigDecimal lastAmount) {
		this.lastAmount = lastAmount;
	}

	@Override
	public String toString() {
		return "PayPlan [paymentId=" + paymentId + ", totalAmount=" + totalAmount + ", numberOfPayments="
				+ numberOfPayments + ", regularPaymentAmount=" + regularPaymentAmount + ", lastAmount=" + lastAmount
				+ "]";
	}
	
	

}
