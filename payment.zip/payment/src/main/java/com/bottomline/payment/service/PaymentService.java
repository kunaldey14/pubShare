package com.bottomline.payment.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.payment.model.PayPlan;
import com.bottomline.payment.repository.PaymentRepository;

@Service
public class PaymentService {
	
	@Autowired
	PaymentRepository payRepo;
	
	public PayPlan save(PayPlan plan)
	{
		//BigDecimal has method to give decimal precision as required .The requirement was to have two decimal places
		//Regular payment is - supplied total amount divided by Number of Payments
		BigDecimal regular = plan.getTotalAmount().divide(BigDecimal.valueOf(plan.getNumberOfPayments()),2, RoundingMode.HALF_UP);
		
		//To calculate the last amount which may differ from regular amount we need to find the regular Total Amount
		//Regular total amount would be Regular amount multiplied by (number of payment - 1)
		// lets say total amount = 10 , no. of Payments = 3 , so regular amount become 10/3 = 3.33
		// Total regular amount is then 3.33 * (3 - 1) = 6.66
		// So last remaining amount would be = Total Amount - Total regular amount = 10 - 6.66 = 3.34
		BigDecimal regtotalAmount = regular.multiply(BigDecimal.valueOf(plan.getNumberOfPayments()).subtract(new BigDecimal(1)));
		BigDecimal lastAmount = plan.getTotalAmount().subtract(regtotalAmount);
		
		plan.setRegularPaymentAmount(regular);
		
		// setting Last Amount to null if regular amount differs from last amount
		if(regular.compareTo(lastAmount) != 0)
			plan.setLastAmount(lastAmount);
		else
			plan.setLastAmount(null);
		
		return payRepo.save(plan);
	}

}
