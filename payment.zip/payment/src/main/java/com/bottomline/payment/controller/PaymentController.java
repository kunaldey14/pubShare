package com.bottomline.payment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.payment.model.PayPlan;
import com.bottomline.payment.repository.PaymentRepository;
import com.bottomline.payment.service.PaymentService;

@RestController
@RequestMapping("/bt")
public class PaymentController {
	
	@Autowired
	PaymentRepository payRepo;
	
	@Autowired
	PaymentService payService;
	
	@GetMapping("/payment")
	public ResponseEntity<List<PayPlan>> getAllTutorials() {
		try {
			List<PayPlan> pay_plan = payRepo.findAll();

			if (pay_plan.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(pay_plan, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/payment/{id}")
	public ResponseEntity<PayPlan> getPaymentPlanById(@PathVariable("id") long id) {
		try {
			Optional<PayPlan> pay_plan = payRepo.findById(id);

			if (!pay_plan.isPresent()) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}

			return new ResponseEntity<>(pay_plan.get(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/payment")
	public ResponseEntity<PayPlan> createPayment(@RequestBody PayPlan paymentPlan) {
		try {
			PayPlan plan = payService.save(paymentPlan);
			return new ResponseEntity<>(plan, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
